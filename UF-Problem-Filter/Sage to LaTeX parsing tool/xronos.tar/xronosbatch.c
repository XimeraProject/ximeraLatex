/****************************************************
Copyright 2017 Dana Nowell, all rights reserved.
This is a hack.  Written for my son, Jason Nowell 
in August 2017.

LOTS of assumptions in the code about other parts of the code.
Beware of modifications cascading through the code.  
This was a hack against verbal requirements 
and should be assumed as such.

Licensing:
Commercial use of this code is forbidden with out written permission
The code IS free to use in educational institutions 
and a license for that use is granted herein.

****************************************************/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "dirent.h"

#include "danalib.h"
#include "xronostoollib.h"

#define XBATCH_FILENAME_MAX_LEN 500

static char *Copyright[] = { 
"\nCopyright 2017 by Dana Nowell, All rights Reserved",
"Educational Institutions are herein granted the right to use",
"and modify the code for their own use.  Rights for use in",
"a sale or other Commercial enterprise require written", 
"permission from the author.",
"\n",  /* blank line */
NULL };  /* end marker */


static int RequiredArgs = 1;  /* how many command line arguments are required as opposed to optional */

static char *Instructions[] = { 
"Needs arguments: shellscript file name is required\n",
"It can be followed by:",
"\t -Debug or /Debug to allow global debug tracing of the program for locating processing errors.",
"\t -XronosPath=\"path\" or /XronosPath=\"path\" to set the path for the xronosfmt program.",
"\t\t\t e.g., -XronosPath=\"/home/me/xronosfmt/bin/\"",
"\t -xronosfmt_outputpath=\"path\" or /xronosfmt_outputpath=\"path\" to set the -output_path flag for the xronosfmt program.",
"It is NOT expected that these switches will be used in production, more of a development tool.",
NULL };  /* end marker */


static char *ShellFileTop[] = { 
"#",
"# this file contains a group of xronosfmt runs that concatenate their output ",
"# into a single log file.  It was created by walking over a direcotry, finding ",
"# all the .tex files and outputting a line to run xronosfmt on that file.",
"#",
"\n",
"echo xronosbatch run on `date` > xronosbatch.log",
"\n",
NULL };  /* end marker */


char CurrentDirectory[XBATCH_FILENAME_MAX_LEN + 1];
char xronos_path[XBATCH_FILENAME_MAX_LEN + 1];
char xronosfmt_outputpath[XBATCH_FILENAME_MAX_LEN + 1];


/*************************************
*  we have all the options loaded, some may need to be cleaned up
*************************************/
static void TrimQuotesFromString( char *line )
{
	char Quote;
	char *MyBuffer;
	char *p;
	
	
	p = line;
	Quote = '\"';

	/* see if we start with a quote and if so, which type */
	if ( *p == Quote )
		++p;
	else 
	{
		Quote = '\'';
		if ( *p == Quote )
		{
			++p;
		}
		else
			Quote = 0;
	}
	
	/* did we start with one? */
	if ( Quote != 0 )
	{  /* OK look for a close quote of the same type */
		MyBuffer = GetMemoryBlock( strlen(line) + 1);  /* get some working space */
		strcpy( MyBuffer, p );  /* skip over the open quote */
		p = FindEndOfString( MyBuffer ); /* last character */
		if ( *p == Quote ) /* look for a close quote */
		{
			*p = 0;
			strcpy( line, MyBuffer );  /* put it back, we have matching quotes we dealt with */
		}
		FreeMemoryBlock( MyBuffer );  /* clean up working space */
		
	}
	

}



/*************************************
*************************************/
static void ProcessCommandLineSwitch( char *MySwitch, char *Value )
{
	char buf[300];
	char *p;
	
	if ( MySwitch == NULL || *MySwitch == 0 ) /* do we actual have a switch at all */
		return;
	
	if ( strlen( MySwitch ) >= sizeof( buf ) )  /* too long for a real switch do not overrun buffer */
		return;
	
	strcpy( buf, MySwitch );
	
		/* Make it lower case */
	for ( p = buf; *p != 0; ++p )
		*p = tolower((unsigned char) *p);

	if ( strcmp( buf, "debug" ) == 0 )  /* debug */
		TraceOn( TRUE );
	else
	if ( strcmp( buf, "xronosfmt_outputpath" ) != 0 )  /* output_path */
	{

		TrimQuotesFromString( Value );
		strcpy( xronosfmt_outputpath, Value );
		p = FindEndOfString(xronosfmt_outputpath); /* last character */
		if ( strlen( xronosfmt_outputpath ) > 0 && *p != '/' )
			strcat( xronosfmt_outputpath, "/" );  /* add ending / to path */	
	}
	else 		
	if ( strcmp( buf, "xronospath" ) != 0 )  /* xronospath */
	{

		TrimQuotesFromString( Value );
		strcpy( xronos_path, Value );
		p = FindEndOfString( xronos_path ); /* last character */
		if ( strlen( xronos_path ) > 0 && *p != '/' )
			strcat( xronos_path, "/" );  /* add ending / to path */	

	}
	else
		{
			sprintf( buf, "Unknown command line switch %s", MySwitch );
			ErrorExit( buf );
		}

}


/*************************************
*************************************/
int main( int argc, char *argv[])
{
	char *p;
	char *Switch, *Value;
	char ParseBuffer[XBATCH_FILENAME_MAX_LEN];
	int i;
	char EntryType[100];
	char tempbuffer[1000];
	FILE *OutFile;
	DIR *dir;
	struct dirent *ent;
	
	/* initialize trace to off */
	TraceInit( );
	SetTraceOutput( stderr ); 
	TraceOn( FALSE );

	DL_CL_ProcessArgs( argc, argv );


	/* display copyright */
	p = DL_CL_GetProgName( );
	fprintf( stderr, "%s\n", p );
	for( i = 0; Copyright[i] != NULL; ++i )
	{
		fputs( Copyright[i], stderr );
		fputs( "\n", stderr );
	}

	/* process command line switches to modify behavior */
	for ( i = 0; DL_CL_GetSwitch( i, &Switch, &Value ); i++ )
	{
		ProcessCommandLineSwitch( Switch, Value );
	}


	/* display instructions */
	if ( DL_CL_GetArgCount() < RequiredArgs )
	{
		for( i = 0; Instructions[i] != NULL; ++i )
		{
			fputs( Instructions[i], stderr );
			fputs( "\n", stderr );
		}
	
		ErrorExit( "\n" );
	}	

	OutFile = fopen( DL_CL_GetArg( 0 ), "w+" );
	if ( OutFile == NULL )
		ErrorExit( "Unable to open the output file for the shell script" );
	
	
	
	/* output the shell command to the output file */
	fputs( "#!/bin/sh\n\n", OutFile );	
	
	/* output a change directory to here to the output file */
	if ( getcwd(CurrentDirectory, sizeof(CurrentDirectory) - 1) == NULL )
	{
		CurrentDirectory[0] = 0;
		puts( "# Failed to get current working directory" );
	}
	else

		fprintf( OutFile, "cd %s\n", CurrentDirectory );

		/* output the top of the shell script file to setup the log etc.*/
	for( i = 0; ShellFileTop[i] != NULL; ++i )
	{
		fputs( ShellFileTop[i], OutFile );
		fputs( "\n", OutFile );
	}
	
	

	if ( (dir = opendir ("./")) == NULL ) 
		ErrorExit( "Can not open directory" );

	
	/* print all the files and directories within directory */
	while ((ent = readdir (dir)) != NULL) 
	{
		TracePrintf( "Processing Directory Entry - %s (d_type = %d)\n", ent->d_name, (int) ent->d_type );
		switch( (int) ent->d_type )
		{
			case 4:
				strcpy( EntryType, "Directory" );  /* setting entry type for TracePrintf at end of switch */
				break;
			
			case 8:
				strcpy( EntryType, "File" );  /* setting entry type for TracePrintf at end of switch */
				strcpy( tempbuffer, ent->d_name );
				p = TrimWhitespace( tempbuffer );
				strcpy( ParseBuffer, p );
				p = strstr( ParseBuffer, "HELP.tex" );
				if ( p == NULL )  /* do not process HELP files */
				{
					p = strstr( ParseBuffer, ".tex" );
					if ( p != NULL && strlen(p) == strlen( ".tex" ) ) /* have a .tex file */
					{
						*p = 0; /* terminate truncating the .tex */
						fprintf( OutFile, "echo ### >> xronosbatch.log \n" );
						fprintf( OutFile, "echo ### FILE %s.tex >> xronosbatch.log \n", ParseBuffer );
						fprintf( OutFile, "echo ### >> xronosbatch.log \n" );
						fprintf( OutFile, "pdflatex -synctex=1 -interaction=nonstopmode %s.tex\n", ParseBuffer );
						fprintf( OutFile, "sage %s.sagetex.sage\n", ParseBuffer );				
						if ( strlen(xronos_path) > 0 )
							fprintf( OutFile, "%s", xronos_path );
						fprintf(OutFile, "xronosfmt %s.tex ",  ParseBuffer );
						if ( strlen(xronosfmt_outputpath) > 0 )
							fprintf( OutFile, " -output_path=\"%s\" ", xronosfmt_outputpath );
						fprintf(OutFile, " >>xronosbatch.log\n" );
						fprintf( OutFile, "echo ### >> xronosbatch.log \n" );
						fprintf( OutFile, "echo ### >> xronosbatch.log \n" );
						fprintf( OutFile, "echo ### >> xronosbatch.log \n" );
					}
				}
				break;
				
			default:
				sprintf( EntryType, "unknown(%d)", (int) ent->d_type );
				break;
		}
		TracePrintf( "Finished Directory Entry - %s, type %s\n", ent->d_name, EntryType );
	}
	
	closedir (dir);
	fclose( OutFile );

	return 0;
}
