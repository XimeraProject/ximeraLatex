#!/bin/sh
make 2>&1 | tee make.log


