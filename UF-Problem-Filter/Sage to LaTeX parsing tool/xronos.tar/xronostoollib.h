/****************************************************
Copyright 2017 Dana Nowell, all rights reserved.
This is a hack.  Written for my son, Jason Nowell 
in August 2017.

LOTS of assumptions in the code about other parts of the code.
Beware of modifications cascading through the code.  
This was a hack against verbal requirements 
and should be assumed as such.

Licensing:
Commercial use of this code is forbidden with out written permission
The code IS free to use in educational institutions 
and a license for that use is granted herein.

****************************************************/

#ifndef XRONOSTOOLLIBH_INCLUDED

#define XRONOSTOOLLIBH_INCLUDED 1  /* define it so we do not double include */



#define XTL_MAX_FILENAME_SIZE 4500  /* max path is 4K max filename is 256 */


typedef enum { XTL_FileSuccess = 0, XTL_FileExists, XTL_FileDoesNotExist, XTL_FileBadName, XTL_FileUnknownError } XTL_FileStatus;


/*************************************
XTL_FileStatus XTL_CreateEmptyHelpFile( char *TexFileName )

given a tex file name (e.g., foo.tex), 
determine if a help file exists (e.g., foo.HELP.tex)
if not then create an empty help file

return status is an XTL_FileStatus
*************************************/
XTL_FileStatus XTL_CreateEmptyHelpFile( char *TexFileName );

/*************************************
char *XTL_FindComment( char *line );

parses the line looking for %
it ignores \%

returns a pointer to the %
*************************************/
char *XTL_FindComment( char *line );


/*************************************
char *XTL_FindClosingSquareBrace( char *line, int *Braces );

must start with a bracecount > 0
walks the line tracking the ongoing bracecount until we get to zero

returns ptr to the closing brace or NULL
*************************************/
char *XTL_FindClosingSquareBrace( char *line, int *Braces );


/*************************************
char *XTL_FindClosingCurlyBrace( char *line, int *Braces );

must start with a bracecount > 0
walks the line tracking the ongoing bracecount until we get to zero

returns ptr to the closing brace or NULL
*************************************/
char *XTL_FindClosingCurlyBrace( char *line, int *Braces );

#endif
