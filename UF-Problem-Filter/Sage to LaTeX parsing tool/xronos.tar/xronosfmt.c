/****************************************************
Copyright 2017 Dana Nowell, all rights reserved.
This is a hack.  Written for my son, Jason Nowell 
in August 2017.

LOTS of assumptions in the code about other parts of the code.
Beware of modifications cascading through the code.  
This was a hack against verbal requirements 
and should be assumed as such.

Licensing:
Commercial use of this code is forbidden with out written permission
The code IS free to use in educational institutions 
and a license for that use is granted herein.

****************************************************/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "xronosfmt.h"



char OutputFileName[XTL_MAX_FILENAME_SIZE + 1];

static char *Copyright[] = { 
"\nCopyright 2017 by Dana Nowell, All rights Reserved",
"Educational Institutions are herein granted the right to use",
"and modify the code for their own use.  Rights for use in",
"a sale or other Commercial enterprise require written", 
"permission from the author.",
"\n",  /* blank line */
NULL };  /* end marker */

static char *Instructions[] = { "Needs arguments: Inputfile name is required\n",
"It can be followed by:",
"\t -Debug or /Debug to allow global debug tracing of the program for locating processing errors.",
"\t -Tags or /Tags to make tags optional in generation the output file.  If tags exist, use them, else use xronosfmt.out.tex as the output file name.",
"\t -KeepDoc /KeepDoc to leave the document class and other header stuff before the first question plus add an end doc to the file,",
"\t\t normally we strip them out and you get just questions",
"\t -Output_Path=\"path\" or /Output_Path=\"path\" to set the path for the outut files.",
"It is NOT expected that these switches will be used in production, more of a development tool.",
NULL };  /* end marker */

/* commandline switch flags */
static BOOL TagsRequired = TRUE;
BOOL QuestionsOnly = TRUE;
char CurrentDirectory[XTL_MAX_FILENAME_SIZE + 1];
char xronosfmt_outputpath[XTL_MAX_FILENAME_SIZE + 1];

/*************************************
*************************************/
char *GetXronosfmtOutputPath( void )
{
return 	xronosfmt_outputpath;
}

/*************************************
*  we have all the options loaded, some may need to be cleaned up
*************************************/
static void TrimQuotesFromString( char *line )
{
	char Quote;
	char *MyBuffer;
	char *p;
	
	
	p = line;
	Quote = '\"';

	/* see if we start with a quote and if so, which type */
	if ( *p == Quote )
		++p;
	else 
	{
		Quote = '\'';
		if ( *p == Quote )
		{
			++p;
		}
		else
			Quote = 0;
	}
	
	/* did we start with one? */
	if ( Quote != 0 )
	{  /* OK look for a close quote of the same type */
		MyBuffer = GetMemoryBlock( strlen(line) + 1);  /* get some working space */
		strcpy( MyBuffer, p );  /* skip over the open quote */
		p = FindEndOfString( MyBuffer ); /* last character */
		if ( *p == Quote ) /* look for a close quote */
		{
			*p = 0;
			strcpy( line, MyBuffer );  /* put it back, we have matching quotes we dealt with */
		}
		FreeMemoryBlock( MyBuffer );  /* clean up working space */
		
	}
	

}



/*************************************
*************************************/
static void WriteOutputFile( char *OutputFileName )
{
	FILE *Out;
	int num;
	XTL_FileStatus XTLFileStat;
	
	
	printf( "Checking to see if we need to make the directory for the output file %s\n", OutputFileName );
	MakeDirChainForFile( OutputFileName );
	
	printf( "Opening output file %s - ", OutputFileName );
	
	/* Create an empty HELP.tex if we need to */
	XTLFileStat = XTL_CreateEmptyHelpFile(OutputFileName );
	if ( XTLFileStat == XTL_FileExists )
		printf( "HELP file for TEX file %s already exists, leaving it alone\n", OutputFileName);
	else				
	if ( XTLFileStat != XTL_FileSuccess )
		printf( "Failed to create HELP file for TEX file %s, continuing on anyway\n", OutputFileName );
				
	/* now write the actual output file */
	Out = fopen( OutputFileName, "w+");
	if ( Out == NULL )
		ErrorExit( "Failed to open output file" );

	puts( "Writing file header data" );
	
	/* we built a custom header before (see BuildHeader.c) now write it out */
	if ( WriteOutputHeader( Out ) != 0 )
		ErrorExit( "Error writing output file header" );

	puts( "Writing actual file data" );

	/* DANA - FIXUP */
	while ( ReadLine( ) == 0 )
	{	
	num = fwrite(LineBuffer, 1, strlen(LineBuffer), Out );
	}
	
	if ( !QuestionsOnly	 )  /* if the user requested we include the document structure stuff intact */
		fputs( "\\end{document}", Out ); /* write the end document line */
	else
		fputs( "\\fi \t\t%% end of \\ifquestionCount near top of file", Out ); /* write the end of the if for the question count conditional at the top of the document */
			
		

	fclose(Out);
	puts( "output file complete" );

}



/*************************************
*************************************/
static void ProcessCommandLineSwitch( char *MySwitch, char *Value )
{
	char buf[200];
	char *p;

	if ( MySwitch == NULL || *MySwitch == 0 ) /* do we actual have a switch at all */
		return;
	
	if ( strlen( MySwitch ) >= sizeof( buf ) )  /* too long for a real switch do not overrun buffer */
		return;
	
	strcpy( buf, MySwitch );
	
		/* Make it lower case */
	for ( p = buf; *p != 0; ++p )
		*p = tolower((unsigned char) *p);
	
	if ( strcmp( "debug", buf ) == 0 )  /* debug */
		TraceOn( TRUE );
	else 
	if ( strcmp( "keepdoc", buf ) == 0 )  /* debug */
		QuestionsOnly = FALSE;
	else 
	if ( strcmp( "output_path", buf ) == 0 )  /* output_path */
	{
		TrimQuotesFromString( Value );
		strcpy( xronosfmt_outputpath, Value );
		p = FindEndOfString(xronosfmt_outputpath); /* last character */
		if ( *p != '/' )
			strcat( xronosfmt_outputpath, "/" );  /* add ending / to path */	
	}
	else 
	if ( strcmp( "tags", buf ) == 0 ) /* tags optional */
		TagsRequired = FALSE;
	else
		{
			sprintf( buf, "Unknown command line switch %s", MySwitch );
			ErrorExit( buf );
		}
}


/*************************************
*************************************/
int main( int argc, char *argv[])
{
char *p;
char *Switch, *Value;
char InputFileName[200];
int i;
	
/* initialize trace to off */
TraceInit(  );
SetTraceOutput( stdout );  /* defaults to stderr if not set, we want stdout */
TraceOn( FALSE );

DL_CL_ProcessArgs( argc, argv );
p = DL_CL_GetProgName( );

printf( "%s", p );
for( i = 0; Copyright[i] != NULL; ++i )
	puts( Copyright[i] );
	
if ( getcwd(CurrentDirectory, sizeof(CurrentDirectory) - 1) == NULL )
{
	CurrentDirectory[0] = 0;
	puts( "Failed to get current working directory" );
}


if (  DL_CL_GetArgCount() != 1 )
{
	for( i = 0; Instructions[i] != NULL; ++i )
		puts( Instructions[i] );
	
	ErrorExit( "\n" );
}
	
strcpy( InputFileName, DL_CL_GetArg( 0 ) );


for ( i = 0; DL_CL_GetSwitch( i, &Switch, &Value ); i++ )
{
	ProcessCommandLineSwitch( Switch, Value );
}

/* initialize the XronosIO library */
XronosIOInit();

/* Load file into memory */
printf( "*** Reading input file: %s\n", InputFileName );
ReadInputFile( InputFileName );

/* handle merge - MUST be first before all other passes over the "file" */
puts( "*** Merge Processing" );
merge( InputFileName );

/* Build Output file header (in memory)*/
RecycleBuffers( );  /* recycle the previous pass output to the new pass input */
puts( "*** Build Output Header for later" );
BuildOutputHeader( TagsRequired );

/* kill dups */
RecycleBuffers( );  /* recycle the previous pass output to the new pass input */
puts( "*** Killing Dups" );
KillDups( );

/* deal with braces */
RecycleBuffers( );  /* recycle the previous pass output to the new pass input */
puts( "*** Braces processing" );
Braces( );

/* deal with question limit on file size */
RecycleBuffers( );  /* recycle the previous pass output to the new pass input */
puts( "*** Question Limit processing" );
QuestionLimit( );

/* write output file */
RecycleBuffers( );  /* recycle the previous pass output to the new pass input */
puts( "*** Writing Output file" );
WriteOutputFile( OutputFileName );

printf( "xronosfmt Question Count for file %s is %d\n", OutputFileName, GetActualQuestionCount() );
puts( "*** Program Complete\n" );
return 0;
}
